package sg.gowild.memobot;

public class User {

    private int id;
    private String fullName;
    private String blkAddress;
    private String streetAddress;
    private String unitNumAddress;
    private MMSE_Test test;

    User(int id, String fullName, String blkAddress, String streetAddress, String unitNumAddress, MMSE_Test test) {
        this.id = id;
        this.fullName = fullName;
        this.blkAddress = blkAddress;
        this.streetAddress = streetAddress;
        this.unitNumAddress = unitNumAddress;
        test = test;
    }


    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getFullName()
    {
        return fullName;
    }

    public String getBlkAddress()
    {
        return blkAddress;
    }

    public String getStreetAddress()
    {
        return streetAddress;
    }

    public String getUnitNumAddress()
    {
        return  unitNumAddress;
    }

    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    public void setBlkAddress(String blkAddress)
    {
        this.blkAddress = blkAddress;
    }

    public void setStreetAddress(String streetAddress)
    {
        this.streetAddress = streetAddress;
    }

    public void setUnitNumAddress(String unitNumAddress)
    {
        this.unitNumAddress = unitNumAddress;
    }

    public String toString()
    {
        return "Registration:{ID_ " + getId() + " Name_" + getFullName() + "Address_" + getBlkAddress() + getStreetAddress() + getUnitNumAddress() + "}" ;
    }
}
