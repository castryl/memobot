package sg.gowild.memobot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Date;


import ai.api.AIConfiguration;
import ai.api.AIDataService;
import ai.api.AIServiceException;
import ai.api.model.AIRequest;
import ai.api.model.AIResponse;
import ai.api.model.Fulfillment;
import ai.api.model.Result;
import ai.kitt.snowboy.SnowboyDetect;
import sg.gowild.sademo.R;

public class MainActivity extends AppCompatActivity {

    // View Variables
    private Button button;
    private TextView textView;

    private int count;

    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    Date date = new Date();


    private String userAnswer;

    private int currenthour;

    private int totalScore = 0;
    private String year;
    private String street;
    private String repeats;
    private String month;
    private String spelling;
    private String repeatObjects;
    private String counts;
    private String end;
    private String repeatAfter;
    private int tries = 0;
    private int regTries = 0;

    //Place to fill in Patient Details;
    private String patientFullname;
    private String patientBlkAddress;
    private String patientStreetAddress;
    private String patientUnitNumAddress;
    private String patientNRIC;

    private String notTime = "It is not time for your Mini-Mental State Examination, if you want we can have a small talk!";

    // ASR Variables
    private SpeechRecognizer speechRecognizer;
    //ASR = Automatic Speech Recognition

    // TTS Variables
    private TextToSpeech textToSpeech;
    // TTS = Text to Speech

    // NLU Variables
    private AIDataService aiDataService;
    //NLU = Natural language understanding

    MMSE_Test newTest = new MMSE_Test(year,street, repeatAfter,repeats, month,spelling,repeatObjects,counts,totalScore);
    User user = new User(1, "", "", "", "", newTest);

    // Hotword Variables
    private boolean shouldDetect;
    private ArrayList<String> doctorSchedule = new ArrayList<>();

    private SnowboyDetect snowboyDetect;

    static {
        System.loadLibrary("snowboy-detect-android");
    }

    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TODO: Setup Components
        setupViews();
        setupXiaoBaiButton();
        setupAsr();
        setupNlu();
        setupTts();
        setupHotword();

        // TODO: Start Hotword
        startHotword();


    }

    private void setupViews() {
        // TODO: Setup Views
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textview);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //textView.setText("Good Morning!");
                shouldDetect = false;
                startAsr();
            }
        });

    }

    private void setupXiaoBaiButton() {
        String BUTTON_ACTION = "com.gowild.action.clickDown_action";

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BUTTON_ACTION);

        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // TODO: Add action to do after button press is detected
                shouldDetect = false;
                startAsr();
            }
        };
        registerReceiver(broadcastReceiver, intentFilter);
    }


    private void setupAsr() {
        // TODO: Setup ASR
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {

            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float rmsdB) {
                //Voice volume change

            }

            @Override
            public void onBufferReceived(byte[] buffer) {



            }

            @Override
            public void onEndOfSpeech() {
                //Show the end of speech, for stop speaking


            }

            @Override
            public void onError(int error) {
                Log.e("asr", "Error: " + Integer.toString(error));
                startHotword();
            }

            @Override
            public void onResults(Bundle results) {
                List<String> texts = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (texts == null || texts.isEmpty())
                {
                    textView.setText("Please try again!");
                } else {
                    userAnswer = texts.get(0);
                    textView.setText(userAnswer);

                    startNlu(userAnswer);
                }

            }
            @Override
            public void onPartialResults(Bundle partialResults) {

            }

            @Override
            public void onEvent(int eventType, Bundle params) {

            }
        });


    }

    private void startAsr() {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                // TODO: Set Language
                final Intent recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en"); //CHANGE_THIS_TO_LANGUAGE
                recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en"); //CHANGE_THIS_TO_LANGUAGE
                recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
                recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH);
                recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

                // Stop hotword detection in case it is still running
                shouldDetect = false;

                // TODO: Start ASR
                speechRecognizer.startListening(recognizerIntent);


            }
        };
        Threadings.runInMainThread(this, runnable);
    }



    private void setupTts() {
        // TODO: Setup TTS
        textToSpeech = new TextToSpeech(this, null);
    }

    private void startTts(String text) {
        // TODO: Start TTS
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        // TODO: Wait for end and start hotword
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                while (textToSpeech.isSpeaking()) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        Log.e("tts", e.getMessage(), e);
                    }
                }


                //hotword has been called once
                if (count > 0)
                {
                    //TODO: Add action after hotword is detected
                    startAsr();
                }
                else
                {
                    startHotword();
                }

                //startHotword();
            }
        };
        Threadings.runInBackgroundThread(runnable);
    }

    private void setupNlu() {
        // TODO: Change Client Access Token
        String clientAccessToken = "dfc4fca4950c42bebcfbdad8eb7cc34b";
        AIConfiguration aiConfiguration = new AIConfiguration(clientAccessToken,
                AIConfiguration.SupportedLanguages.English);
        aiDataService = new AIDataService(aiConfiguration);
    }

    private void startNlu(final String text) {
        // TODO: Start NLU
        Runnable runnable = new Runnable() {

            @Override
            public void run() {
                AIRequest aiRequest = new AIRequest();
                aiRequest.setQuery(text);

                try {
                    AIResponse aiResponse = aiDataService.request(aiRequest);

                    Result result = aiResponse.getResult();
                    Fulfillment fulfillment = result.getFulfillment();
                    String responseText = fulfillment.getSpeech();

                    if (responseText.equalsIgnoreCase("intro_function")) {
                        responseText = welcomeMessage();
                    } else if (responseText.equalsIgnoreCase("intro2_function")) {
                        responseText = welcomeMessage2();
                    } else if (responseText.equalsIgnoreCase("verification_function")) {
                        responseText = verifyByNRIC();
                    } else if (responseText.equalsIgnoreCase("question1_function")) {
                        responseText = question1();
                    } else if (responseText.equalsIgnoreCase("question2_function")) {
                        responseText = question2();
                    } else if (responseText.equalsIgnoreCase("question3_function")) {
                        responseText = question3();
                    } else if (responseText.equalsIgnoreCase("question4_function")) {
                        responseText = question4();
                    } else if (responseText.equalsIgnoreCase("question5_function")) {
                        responseText = question5();
                    } else if (responseText.equalsIgnoreCase("question6_function")) {
                        responseText = question6();
                    } else if (responseText.equalsIgnoreCase("question7_function")) {
                        responseText = question7();
                    } else if (responseText.equalsIgnoreCase("question8_function")) {
                        responseText = question8();
                    } else if (responseText.equalsIgnoreCase("endTest_function")) {
                        responseText = endTest();
                    } else if (responseText.equalsIgnoreCase("bye_function")) {
                        responseText = "Good bye";
                        count = 0;
                    }

                    //RegisterPatient - Check
                    else if (responseText.equalsIgnoreCase("checkreg_function")) {
                        responseText = regCheck();
                    }

                    //RegisterPatient - Start
                    else if (responseText.equalsIgnoreCase("reg_function")) {
                        responseText = regPatient();
                    }

                    //RegisterPatient - NRIC
                    else if (responseText.equalsIgnoreCase("regFullName_function")) {
                        responseText = regfullName();
                    }

                    //RegisterPatient - Blk Address
                    else if (responseText.equalsIgnoreCase("regNRIC_function")) {
                        responseText = regNRIC();
                    }

                    //RegisterPatient - Street Address
                    else if (responseText.equalsIgnoreCase("regBlk_function")) {
                        responseText = regBlkAddress();
                    }

                    //RegisterPatient - Unit Number Address
                    else if (responseText.equalsIgnoreCase("regStreet_function")) {
                        responseText = regStreetAddress();
                    }

                    //RegisterPatient - End
                    else if (responseText.equalsIgnoreCase("regUnitNum_function")) {
                        responseText = regUnitNumAddress();
                    }
                    //Incorrect Answer
                    else if (responseText.equalsIgnoreCase("incorrectQuestion_function")) {
                        responseText = incorrectQuestion();
                    }

                    //Incorrect Registration Answer
                    else if (responseText.equalsIgnoreCase("incorrectRegistrationQuestion_function")) {
                        responseText = incorrectQuestionRegistration();
                    }


                    startTts(responseText);
                    //while person is talking, add write to the database

                    String datetime = String.valueOf(date);
                    DatabaseReference myRef = database.getReference().child("Results").child(datetime);//for every instance the user does the test
                    //myRef.setValue(newTest);
                    myRef.setValue(newTest);


                } catch (AIServiceException e) {
                    Log.e("null", e.getMessage(), e);
                }
            }
        };
        Threadings.runInBackgroundThread(runnable);

    }


    private void setupHotword() {
        shouldDetect = false;
        SnowboyUtils.copyAssets(this);

        // TODO: Setup Model File
        File snowboyDirectory = SnowboyUtils.getSnowboyDirectory();
        File model = new File(snowboyDirectory, "Memobot.pmdl");
        File common = new File(snowboyDirectory, "common.res");

        // TODO: Set Sensitivity
        snowboyDetect = new SnowboyDetect(common.getAbsolutePath(), model.getAbsolutePath());
        snowboyDetect.setSensitivity("0.60");
        snowboyDetect.applyFrontend(true);
    }

    private void startHotword() {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                shouldDetect = true;
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);

                int bufferSize = 3200;
                byte[] audioBuffer = new byte[bufferSize];
                AudioRecord audioRecord = new AudioRecord(
                        MediaRecorder.AudioSource.DEFAULT,
                        16000,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        bufferSize
                );

                if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                    Log.e("hotword", "audio record fail to initialize");
                    return;
                }

                audioRecord.startRecording();
                Log.d("hotword", "start listening to hotword");

                while (shouldDetect) {
                    audioRecord.read(audioBuffer, 0, audioBuffer.length);

                    short[] shortArray = new short[audioBuffer.length / 2];
                    ByteBuffer.wrap(audioBuffer).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shortArray);

                    int result = snowboyDetect.runDetection(shortArray, shortArray.length);
                    if (result > 0) {

                        shouldDetect = false;
                        count = 1;
                    }
                }

                audioRecord.stop();
                audioRecord.release();
                Log.d("hotword", "stop listening to hotword");

                // TODO: Add action after hotword is detected
                startAsr();
            }
        };
        Threadings.runInBackgroundThread(runnable);
    }


    //get scheduled hours from database and put them in an array, check all array with current time
    private boolean checkTime()
    {
        Calendar getHour = Calendar.getInstance();
        int currentHour = getHour.get(Calendar.HOUR_OF_DAY); // return the hour in 24 hrs format (ranging from 0-23)
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,doctorSchedule);
        //read time from database
       DatabaseReference myRef2 = database.getReference().child("time");
        myRef2.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                String timevalue = (String) dataSnapshot.child("testTime").getValue();
                doctorSchedule.add(timevalue);
                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //if the current time is same as doctor's scheduled time
        if (doctorSchedule.contains(String.valueOf(currentHour)))
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    private String welcomeMessage() {
        Random rand = new Random();
        int i = rand.nextInt(3);

        String greet[] = {"Hi", "Hi there", "Hello"};

        checkName();
        checkNRIC();
        checkBlk();
        checkStreet();
        checkUnitNum();

        if (patientFullname == null || patientFullname.isEmpty()) {

            return greet[i] + "! You have not register your name to me, please do so by saying I want to register a patient onto this device";
        } else if (patientNRIC == null || patientNRIC.isEmpty()) {
            return greet[i] + "! You have not register your NRIC to me, please do so by saying I want to register a patient onto this device";
        } else if (patientBlkAddress == null || patientBlkAddress.isEmpty()) {
            return greet[i] + "! You have not register your block address to me, please do so by saying I want to register a patient onto this device";
        } else if (patientStreetAddress == null || patientStreetAddress.isEmpty()) {
            return greet[i] + "! You have not register your street address to me, please do so by saying I want to register a patient onto this device";
        } else if (patientUnitNumAddress == null || patientUnitNumAddress.isEmpty()) {
            return greet[i] + "! You have not register your unit number to me, please do so by saying I want to register a patient onto this device";
        } else if (checkTime()) {
            return greet[i] + "! It is time for your Mini-Mental State Examination, would you like to begin?";
        } else {
            return greet[i] + "! It is not time for your Mini-Mental State Examination, if you want we can have a small talk!";
        }
    }

    private String welcomeMessage2() {

        checkName();
        checkNRIC();
        checkBlk();
        checkStreet();
        checkUnitNum();

        if (patientFullname == null || patientFullname.isEmpty()) {

            return "Sorry! You have not register your name to me, please do so by saying I want to register a patient onto this device";
        } else if (patientNRIC == null || patientNRIC.isEmpty()) {
            return "Sorry! You have not register your N R I C to me, please do so by saying I want to register a patient onto this device";
        } else if (patientBlkAddress == null || patientBlkAddress.isEmpty()) {
            return "Sorry! You have not register your block address to me, please do so by saying I want to register a patient onto this device";
        } else if (patientStreetAddress == null || patientStreetAddress.isEmpty()) {
            return "Sorry! You have not register your street address to me, please do so by saying I want to register a patient onto this device";
        } else if (patientUnitNumAddress == null || patientUnitNumAddress.isEmpty()) {
            return "Sorry! You have not register your unit number to me, please do so by saying I want to register a patient onto this device";
        } else if (checkTime()) {
            if (userAnswer.contains("Can I start the test now?")) {
                return "Yes! Would you like to begin now?";
            } else {
                return "Sure! Would you like to begin now?";
            }
        } else {
            return "Sorry! It is not time for your Mini-Mental State Examination, if you want we can have a small talk!";
        }
    }

    private String verifyByNRIC() {
        Random rand = new Random();
        int i = rand.nextInt(2);

        String agreement[] = {"Alright", "Great"};

        if (checkTime()) {
            return agreement[i] + "! Before we begin, please tell me your N R I C for verification!";
        } else {
            return notTime;
        }
    }

    private String question1() {

        checkNRIC();

        if (userAnswer.contains(patientNRIC)) {
            if (checkTime()) {
                totalScore = 0; //Resets total score;
                tries = 0;
                return "Correct!, let's begin. Question 1: What is the year?";
            } else {
                return notTime;
            }
        } else {
            return "Incorrect, please provide me the correct N R I C ";
        }

    }

    private void checkNRIC() {

        patientNRIC = null;

        try {
            FileInputStream fileInputStream = openFileInput("MemobotPatientNRIC.txt");
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while ((read = fileInputStream.read()) != -1) {
                buffer.append((char) read);
            }

            patientNRIC = buffer.substring(0);

            fileInputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private String question2() {
        Calendar getYear = Calendar.getInstance();
        int currentYear = getYear.get(Calendar.YEAR);


        if (checkTime()) {
            if (userAnswer.contains(String.valueOf(currentYear))) {
                totalScore += 1;
            }
            tries = 0;
            newTest.setYear(userAnswer);
            newTest.setScore(totalScore);
            return "Right. Question 2: What street do you live on?";
        } else {
            return notTime;
        }

    }

    private String question3() {
        if (checkTime()) {

            checkStreet();

            if (patientStreetAddress.contains(userAnswer)) {
                totalScore += 1;
            }
            newTest.setStreet(userAnswer);
            newTest.setScore(totalScore);
            tries = 0;
            return "Good. Question 3: Repeat the phrase: No ifs, ands, or buts.";
        } else {
            return notTime;
        }

    }

    private String question4() {
        if (checkTime()) {

            if ("no".contains(userAnswer.toLowerCase())) {
                if ("if".contains(userAnswer.toLowerCase())
                        || "ifs".contains(userAnswer.toLowerCase())
                        || "ifs,".contains(userAnswer.toLowerCase())) {
                    if ("and".contains(userAnswer.toLowerCase())
                            || "ands".contains(userAnswer.toLowerCase())
                            || "ands,".contains(userAnswer.toLowerCase())) {
                        if ("or".contains(userAnswer.toLowerCase())) {
                            if ("but".contains(userAnswer.toLowerCase())
                                    || "buts".contains(userAnswer.toLowerCase())) {
                                totalScore += 1;
                            }
                        }
                    }
                }
            }
            tries = 0;
            newTest.setRepeatAfter(userAnswer);
            newTest.setScore(totalScore);
            return "Great. Question 4: What is the current month?";
        } else {
            return notTime;
        }
    }

    private String question5() {
        String[] monthName = {"January", "February",
                "March", "April", "May", "June", "July",
                "August", "September", "October", "November",
                "December"};

        Calendar getMonth = Calendar.getInstance();
        String currentMonth = monthName[getMonth.get(Calendar.MONTH)];

        if (checkTime()) {
            if (currentMonth.toLowerCase().contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }
            tries = 0;
            newTest.setMonth(userAnswer);
            newTest.setScore(totalScore);
            return "Indeed! Question 5. Ball. Car. Moon. Please memorize these objects and repeat them to me.";
        } else {
            return notTime;
        }
    }

    private String question6() {
        if (checkTime()) {
            if ("ball".contains(userAnswer.toLowerCase())
                    || "ball,".contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }

            if ("car".contains(userAnswer.toLowerCase())
                    || "car,".contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }

            if ("moon".contains(userAnswer.toLowerCase())
                    || "moon,".contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }

            tries = 0;
            newTest.setRepeat(userAnswer);
            newTest.setScore(totalScore);
            return "Very Good. Question 6: Spell 'apple' backwards.";
        } else {
            return notTime;
        }
    }


    private String question7() {
        if (checkTime()) {
            if ("elppa".contains(userAnswer.toLowerCase())
                    || "ELP PA".contains(userAnswer.toLowerCase())
                    || "ELP ELP PA".contains(userAnswer.toLowerCase())) {
                totalScore += 5;
            } else {
                if ("e".contains(userAnswer.toLowerCase())) {
                    totalScore += 1;
                }

                if ("l".contains(userAnswer.toLowerCase())) {
                    totalScore += 1;
                }

                if ("p".contains(userAnswer.toLowerCase())) {
                    totalScore += 2;
                }

                if ("a".contains(userAnswer.toLowerCase())) {
                    totalScore += 1;
                }
            }

            tries = 0;
            newTest.setSpelling(userAnswer);
            newTest.setScore(totalScore);
            return "Well done. Question 7: Earlier I told you the names of three objects. Can you tell me what those were?";
        } else {
            return notTime;
        }
    }

    private String question8() {
        if (checkTime()) {
            if ("ball".contains(userAnswer.toLowerCase())
                    || "ball,".contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }

            if ("car".contains(userAnswer.toLowerCase())
                    || "car,".contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }

            if ("moon".contains(userAnswer.toLowerCase())
                    || "moon,".contains(userAnswer.toLowerCase())) {
                totalScore += 1;
            }

            tries = 0;
            newTest.setRepeatObjects(userAnswer);
            newTest.setScore(totalScore);
            return "Great. Last question: Please count backward from 30 by multiples of 6.";
        } else {
            return notTime;
        }
    }

    private String endTest() {
        if (checkTime()) {
            if ("3024 1812 6".contains(userAnswer)
                    || "3024 1812 6 0".contains(userAnswer)
                    || "302418126".contains(userAnswer)
                    || "3024 18126".contains(userAnswer)
                    || "302418 126".contains(userAnswer)
                    || "30 2418 126".contains(userAnswer)) {
                totalScore += 5;
            } else {
                if ("30".contains(userAnswer)) {
                    totalScore += 1;
                }
                if ("24".contains(userAnswer)) {
                    totalScore += 1;
                }
                if ("18".contains(userAnswer)) {
                    totalScore += 1;
                }
                if ("12".contains(userAnswer)) {
                    totalScore += 1;
                }
                if ("6".contains(userAnswer)) {
                    totalScore += 1;
                }
            }
            tries = 0;
            count = 0;
            newTest.setCount(userAnswer);
            newTest.setScore(totalScore);
            return "Well done. We have come to the end of the Mini-Mental State Examination. Your score is" + totalScore + "out of twenty. Nicely done!";
        } else {
            return notTime;
        }
    }

    private String regCheck() {
        checkName();

        if (patientFullname == null || patientFullname.isEmpty()) {
            return "There is no patient being registered to me.";
        } else {
            return "There is a patient being registered to me. The patient name is " + patientFullname;
        }
    }

    private String regPatient() {
        checkName();

        String message = "But there is a patient being registered to me, do you wish to overwrite it?";

        if (patientFullname == null || patientFullname.isEmpty()) {

            checkBlk();

            if (patientBlkAddress == null || patientBlkAddress.isEmpty()) {

                checkStreet();

                if (patientStreetAddress == null || patientStreetAddress.isEmpty()) {

                    checkUnitNum();

                    if (patientUnitNumAddress == null || patientUnitNumAddress.isEmpty()) {
                        return "Do you wish to register now?";
                    } else {
                        return message;
                    }
                } else {
                    return message;
                }
            } else {
                return message;
            }
        } else {
            return message;
        }
    }

    private void checkName() {

        patientFullname = null;

        try {
            FileInputStream fileInputStream = openFileInput("MemobotPatientName.txt");
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while ((read = fileInputStream.read()) != -1) {
                buffer.append((char) read);
            }

            patientFullname = buffer.substring(0);

            fileInputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void checkBlk() {

        patientBlkAddress = null;

        try {
            FileInputStream fileInputStream = openFileInput("MemobotPatientBlkAddress.txt");
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while ((read = fileInputStream.read()) != -1) {
                buffer.append((char) read);
            }

            patientBlkAddress = buffer.substring(0);

            fileInputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void checkStreet() {

        patientStreetAddress = null;

        try {
            FileInputStream fileInputStream = openFileInput("MemobotPatientStreetAddress.txt");
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while ((read = fileInputStream.read()) != -1) {
                buffer.append((char) read);
            }

            patientStreetAddress = buffer.substring(0);

            fileInputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void checkUnitNum() {

        patientUnitNumAddress = null;

        try {
            FileInputStream fileInputStream = openFileInput("MemobotPatientUnitNumAddress.txt");
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while ((read = fileInputStream.read()) != -1) {
                buffer.append((char) read);
            }

            patientUnitNumAddress = buffer.substring(0);

            fileInputStream.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private String regfullName() {
        String filename = "MemobotPatientName.txt";
        String fileContents = userAnswer;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        regTries = 0;
        return "Cool, what is your N R I C number?";

    }

    private String regNRIC() {
        String filename = "MemobotPatientNRIC.txt";
        String fileContents = userAnswer;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        regTries = 0;
        return "Sweet, what is your block number?";
    }

    private String regBlkAddress() {
        String filename = "MemobotPatientBlkAddress.txt";
        String fileContents = userAnswer;
        user.setBlkAddress(userAnswer);
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        regTries = 0;
        return "Alright, what is your street name?";
    }

    private String regStreetAddress() {
        String filename = "MemobotPatientStreetAddress.txt";
        String fileContents = userAnswer;
        user.setStreetAddress(userAnswer);
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        regTries = 0;
        return "Ok, what is your unit number?";
    }

    private String regUnitNumAddress() {
        String filename = "MemobotPatientUnitNumAddress.txt";
        String fileContents = userAnswer;
        user.setUnitNumAddress(userAnswer);
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        regTries = 0;
        count = 0;
        return "Sweet! Your registration is complete!";
    }

    private String incorrectQuestion() {

        if (tries >= 2) {
            tries = 0;
            return "Sorry, you have reach the maximum number of tries. Please restart the test by saying I want to do the Mini-Mental State Examination";
        } else {
            tries += 1;
            return "Sorry, your answer is incorrect!";
        }


    }

    private String incorrectQuestionRegistration() {

        if (regTries >= 2) {
            regTries = 0;
            return "Sorry, you have reach the maximum number of tries. Please restart the registration";
        } else {
            regTries += 1;
            return "Sorry, your answer is incorrect!";
        }


    }

}