package sg.gowild.memobot;


public class MMSE_Test {
    private String year;
    private String street;
    private String repeatAfter;
    private String repeat;
    private String month;
    private String spelling;
    private String repeatObjects;
    private String count;
    private int score;


    MMSE_Test(String year, String street, String repeatAfter, String repeat, String month, String spelling, String repeatObjects, String count, int score)
    {
        this.year = year;
        this.street = street;
        this.repeatAfter = repeatAfter;
        this.repeat = repeat;
        this.month = month;
        this.spelling = spelling;
        this.repeatObjects = repeatObjects;
        this.count = count;
        this.score = score;
    }



    public String getYear() {
        return year;
    }

    public String getStreet() {
        return street;
    }

    public String getRepeatAfter(){return repeatAfter;}

    public String getRepeat() {
        return repeat;
    }

    public String getMonth() {
        return month;
    }

    public String getSpelling() {
        return spelling;
    }

    public String getRepeatObjects() {
        return repeatObjects;
    }

    public String getCount() {
        return count;
    }

    public int getScore() { return score; }

    public void setYear(String year) {
        this.year = year;
    }

    public void setStreet(String street)
    {
        this.street = street ;
    }

    public void setRepeatAfter(String repeatAfter){this.repeatAfter = repeatAfter;}

    public void setRepeat(String repeat)
    {
        this.repeat = repeat ;
    }

    public void setMonth(String month)
    {
        this.month = month ;
    }

    public void setSpelling(String spelling)
    {
        this.spelling = spelling ;
    }

    public void setRepeatObjects(String repeatObjects)
    {
        this.repeatObjects = repeatObjects ;
    }

    public void setCount(String count)
    {
        this.count = count ;
    }


    public void setScore(int score){this.score = score;}


    public String toString()
    {
        return "Response:[" + getYear() + getStreet() + getRepeatAfter() +  getRepeat() + getMonth() + getSpelling() + getRepeatObjects() + getCount() + getScore()+ " ]";

    }




}
